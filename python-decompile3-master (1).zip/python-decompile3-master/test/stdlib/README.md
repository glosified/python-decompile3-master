The programs in here are to test Python stdlib tests  in lib/pythonX.Y/test

We'll compile a test, then decompile it and then run the test
