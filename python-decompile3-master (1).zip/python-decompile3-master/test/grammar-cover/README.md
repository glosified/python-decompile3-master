Code in this directory gets statistics on grammar coverage
