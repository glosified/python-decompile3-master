from __future__ import unicode_literals

# __future__ unicode_literals changes the way we need to print
# the below
# In Python assembler code "a" is u"a" and b"a" is "a".
a  = "a"
ba = b"a"
bb = b"b"
