# Test of building map via kv rules
aa = 'aa'
dict0 = {'a': 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','b': 1234,'d': aa,aa: aa}
