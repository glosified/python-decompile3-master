Making a release is a somewhat tedious process so I've automated it a little


Here are tools that I, rocky, use to check and build a distribution.

They are customized to my environment:
- I use pyenv to various Python versions installed
- I have git repos for xdis, and spark parser at the same level as decompyle3

There may be other rocky-specific things that need customization.
how-to-make-a-release.txt has overall how I make a release
