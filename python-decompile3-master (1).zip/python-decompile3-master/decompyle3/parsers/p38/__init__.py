"""
Here we have Python 3.8 grammars and associated customization
for the both full language and the subset used in lambda expressions.
"""
from decompyle3.parsers.p38.lambda_expr import *
from decompyle3.parsers.p38.full import *
from decompyle3.parsers.p38.base import *
