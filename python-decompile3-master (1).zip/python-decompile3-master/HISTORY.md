This project has history of over 18 years spanning back to Python 1.5

See the [uncompyle6 history](https://github.com/rocky/python-uncompyle6/blob/master/HISTORY.md) details.
